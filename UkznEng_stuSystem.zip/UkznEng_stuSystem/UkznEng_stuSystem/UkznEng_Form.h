#pragma once

namespace UkznEng_stuSystem {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	protected:
	private: System::Windows::Forms::Panel^ login_page;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Button^ Loginbtn;
	private: System::Windows::Forms::TextBox^ PasswordTxt;
	private: System::Windows::Forms::TextBox^ UsernameTxt;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::Panel^ student_page;

	private: System::Windows::Forms::Button^ button2;





	private: System::Windows::Forms::Label^ label8;
	private: System::Windows::Forms::Panel^ student_page1;
	private: System::Windows::Forms::Button^ button3;
	private: System::Windows::Forms::Panel^ panel1;
	private: System::Windows::Forms::Button^ button7;
	private: System::Windows::Forms::Button^ button5;
	private: System::Windows::Forms::Button^ button6;
	private: System::Windows::Forms::Button^ button4;
	private: System::Windows::Forms::Button^ button8;
	private: System::Windows::Forms::Label^ label7;
	private: System::Windows::Forms::ComboBox^ comboBox2;
	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::ComboBox^ comboBox1;
	private: System::Windows::Forms::Panel^ student_page2;






	private: System::Windows::Forms::Button^ button9;
	private: System::Windows::Forms::DataGridView^ dataGridView1;
	private: System::Windows::Forms::Panel^ lecturer_page;
	private: System::Windows::Forms::Panel^ lecturer_page1;


	private: System::Windows::Forms::DataGridView^ dataGridView2;
	private: System::Windows::Forms::Button^ button10;
	private: System::Windows::Forms::Panel^ panel4;
	private: System::Windows::Forms::Button^ button11;
	private: System::Windows::Forms::Button^ button13;
	private: System::Windows::Forms::Button^ button15;
	private: System::Windows::Forms::Button^ button16;
	private: System::Windows::Forms::Label^ label11;
	private: System::Windows::Forms::Panel^ lecturer_page2;
	private: System::Windows::Forms::DataGridView^ dataGridView3;
	private: System::Windows::Forms::Button^ button12;
	private: System::Windows::Forms::Panel^ lecturer_page3;
	private: System::Windows::Forms::DataGridView^ dataGridView4;
	private: System::Windows::Forms::Button^ button14;
	private: System::Windows::Forms::Panel^ admin_page;
	private: System::Windows::Forms::Panel^ admin_page1;


	private: System::Windows::Forms::Button^ button17;
	private: System::Windows::Forms::Panel^ admin_page2;





	private: System::Windows::Forms::Button^ button19;
	private: System::Windows::Forms::Panel^ panel7;
	private: System::Windows::Forms::Button^ button20;

	private: System::Windows::Forms::Button^ button22;
	private: System::Windows::Forms::Button^ button23;
	private: System::Windows::Forms::Label^ label9;
	private: System::Windows::Forms::TextBox^ textBox1;
	private: System::Windows::Forms::Label^ label10;
	private: System::Windows::Forms::Label^ label12;
private: System::Windows::Forms::TextBox^ textBox3;
private: System::Windows::Forms::Label^ label13;
private: System::Windows::Forms::TextBox^ textBox2;
private: System::Windows::Forms::TextBox^ textBox4;
private: System::Windows::Forms::Label^ label14;
private: System::Windows::Forms::TextBox^ textBox5;
private: System::Windows::Forms::Label^ label15;
private: System::Windows::Forms::TextBox^ textBox6;
private: System::Windows::Forms::Label^ label16;

private: System::Windows::Forms::Button^ button21;
private: System::Windows::Forms::Label^ label23;
private: System::Windows::Forms::Label^ label24;
private: System::Windows::Forms::Label^ label25;
private: System::Windows::Forms::TextBox^ textBox13;
private: System::Windows::Forms::TextBox^ textBox14;
private: System::Windows::Forms::Label^ label26;
private: System::Windows::Forms::TextBox^ textBox15;
private: System::Windows::Forms::Label^ label20;

private: System::Windows::Forms::Label^ label21;

private: System::Windows::Forms::Label^ label22;

private: System::Windows::Forms::Label^ label19;
private: System::Windows::Forms::TextBox^ textBox9;
private: System::Windows::Forms::Label^ label18;
private: System::Windows::Forms::TextBox^ textBox8;
private: System::Windows::Forms::Button^ button18;
private: System::Windows::Forms::Label^ label17;
private: System::Windows::Forms::TextBox^ textBox7;
private: System::Windows::Forms::Label^ label28;
private: System::Windows::Forms::Label^ label27;
private: System::Windows::Forms::TextBox^ textBox17;
private: System::Windows::Forms::TextBox^ textBox16;
private: System::Windows::Forms::ComboBox^ comboBox3;
private: System::Windows::Forms::Label^ label29;
private: System::Windows::Forms::TextBox^ textBox10;
private: System::Windows::Forms::RichTextBox^ richTextBox1;
private: System::Windows::Forms::ComboBox^ comboBox4;
private: System::Windows::Forms::ComboBox^ comboBox5;
private: System::Windows::Forms::Label^ label30;
private: System::Windows::Forms::TextBox^ textBox11;

















	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->login_page = (gcnew System::Windows::Forms::Panel());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->Loginbtn = (gcnew System::Windows::Forms::Button());
			this->PasswordTxt = (gcnew System::Windows::Forms::TextBox());
			this->UsernameTxt = (gcnew System::Windows::Forms::TextBox());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->student_page = (gcnew System::Windows::Forms::Panel());
			this->student_page1 = (gcnew System::Windows::Forms::Panel());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->comboBox2 = (gcnew System::Windows::Forms::ComboBox());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->student_page2 = (gcnew System::Windows::Forms::Panel());
			this->label30 = (gcnew System::Windows::Forms::Label());
			this->textBox11 = (gcnew System::Windows::Forms::TextBox());
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->button9 = (gcnew System::Windows::Forms::Button());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->button8 = (gcnew System::Windows::Forms::Button());
			this->button7 = (gcnew System::Windows::Forms::Button());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->lecturer_page = (gcnew System::Windows::Forms::Panel());
			this->lecturer_page3 = (gcnew System::Windows::Forms::Panel());
			this->label28 = (gcnew System::Windows::Forms::Label());
			this->label27 = (gcnew System::Windows::Forms::Label());
			this->textBox17 = (gcnew System::Windows::Forms::TextBox());
			this->textBox16 = (gcnew System::Windows::Forms::TextBox());
			this->comboBox3 = (gcnew System::Windows::Forms::ComboBox());
			this->button21 = (gcnew System::Windows::Forms::Button());
			this->label23 = (gcnew System::Windows::Forms::Label());
			this->label24 = (gcnew System::Windows::Forms::Label());
			this->label25 = (gcnew System::Windows::Forms::Label());
			this->textBox13 = (gcnew System::Windows::Forms::TextBox());
			this->textBox14 = (gcnew System::Windows::Forms::TextBox());
			this->label26 = (gcnew System::Windows::Forms::Label());
			this->textBox15 = (gcnew System::Windows::Forms::TextBox());
			this->dataGridView4 = (gcnew System::Windows::Forms::DataGridView());
			this->button14 = (gcnew System::Windows::Forms::Button());
			this->lecturer_page2 = (gcnew System::Windows::Forms::Panel());
			this->comboBox5 = (gcnew System::Windows::Forms::ComboBox());
			this->label29 = (gcnew System::Windows::Forms::Label());
			this->textBox10 = (gcnew System::Windows::Forms::TextBox());
			this->richTextBox1 = (gcnew System::Windows::Forms::RichTextBox());
			this->comboBox4 = (gcnew System::Windows::Forms::ComboBox());
			this->label20 = (gcnew System::Windows::Forms::Label());
			this->label21 = (gcnew System::Windows::Forms::Label());
			this->label22 = (gcnew System::Windows::Forms::Label());
			this->label19 = (gcnew System::Windows::Forms::Label());
			this->textBox9 = (gcnew System::Windows::Forms::TextBox());
			this->label18 = (gcnew System::Windows::Forms::Label());
			this->textBox8 = (gcnew System::Windows::Forms::TextBox());
			this->button18 = (gcnew System::Windows::Forms::Button());
			this->label17 = (gcnew System::Windows::Forms::Label());
			this->textBox7 = (gcnew System::Windows::Forms::TextBox());
			this->dataGridView3 = (gcnew System::Windows::Forms::DataGridView());
			this->button12 = (gcnew System::Windows::Forms::Button());
			this->lecturer_page1 = (gcnew System::Windows::Forms::Panel());
			this->dataGridView2 = (gcnew System::Windows::Forms::DataGridView());
			this->button10 = (gcnew System::Windows::Forms::Button());
			this->panel4 = (gcnew System::Windows::Forms::Panel());
			this->button11 = (gcnew System::Windows::Forms::Button());
			this->button13 = (gcnew System::Windows::Forms::Button());
			this->button15 = (gcnew System::Windows::Forms::Button());
			this->button16 = (gcnew System::Windows::Forms::Button());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->admin_page = (gcnew System::Windows::Forms::Panel());
			this->admin_page1 = (gcnew System::Windows::Forms::Panel());
			this->textBox3 = (gcnew System::Windows::Forms::TextBox());
			this->label13 = (gcnew System::Windows::Forms::Label());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->label12 = (gcnew System::Windows::Forms::Label());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->button17 = (gcnew System::Windows::Forms::Button());
			this->admin_page2 = (gcnew System::Windows::Forms::Panel());
			this->textBox4 = (gcnew System::Windows::Forms::TextBox());
			this->label14 = (gcnew System::Windows::Forms::Label());
			this->textBox5 = (gcnew System::Windows::Forms::TextBox());
			this->label15 = (gcnew System::Windows::Forms::Label());
			this->textBox6 = (gcnew System::Windows::Forms::TextBox());
			this->label16 = (gcnew System::Windows::Forms::Label());
			this->button19 = (gcnew System::Windows::Forms::Button());
			this->panel7 = (gcnew System::Windows::Forms::Panel());
			this->button20 = (gcnew System::Windows::Forms::Button());
			this->button22 = (gcnew System::Windows::Forms::Button());
			this->button23 = (gcnew System::Windows::Forms::Button());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->login_page->SuspendLayout();
			this->student_page->SuspendLayout();
			this->student_page1->SuspendLayout();
			this->student_page2->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->BeginInit();
			this->panel1->SuspendLayout();
			this->lecturer_page->SuspendLayout();
			this->lecturer_page3->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView4))->BeginInit();
			this->lecturer_page2->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView3))->BeginInit();
			this->lecturer_page1->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView2))->BeginInit();
			this->panel4->SuspendLayout();
			this->admin_page->SuspendLayout();
			this->admin_page1->SuspendLayout();
			this->admin_page2->SuspendLayout();
			this->panel7->SuspendLayout();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(97, 1);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(574, 31);
			this->label1->TabIndex = 0;
			this->label1->Text = L"UKZN ENGINEERING STUDENT SYSTEM";
			// 
			// login_page
			// 
			this->login_page->Controls->Add(this->button1);
			this->login_page->Controls->Add(this->Loginbtn);
			this->login_page->Controls->Add(this->PasswordTxt);
			this->login_page->Controls->Add(this->UsernameTxt);
			this->login_page->Controls->Add(this->label5);
			this->login_page->Controls->Add(this->label4);
			this->login_page->Controls->Add(this->label3);
			this->login_page->Location = System::Drawing::Point(9, 43);
			this->login_page->Name = L"login_page";
			this->login_page->Size = System::Drawing::Size(760, 490);
			this->login_page->TabIndex = 1;
			this->login_page->Paint += gcnew System::Windows::Forms::PaintEventHandler(this, &Form1::login_page_Paint);
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::Color::Transparent;
			this->button1->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button1->ForeColor = System::Drawing::Color::DarkRed;
			this->button1->Location = System::Drawing::Point(680, 3);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(77, 23);
			this->button1->TabIndex = 9;
			this->button1->Text = L"Cancel";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// Loginbtn
			// 
			this->Loginbtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->Loginbtn->Location = System::Drawing::Point(305, 315);
			this->Loginbtn->Name = L"Loginbtn";
			this->Loginbtn->Size = System::Drawing::Size(151, 23);
			this->Loginbtn->TabIndex = 8;
			this->Loginbtn->Text = L"Submit";
			this->Loginbtn->UseVisualStyleBackColor = true;
			this->Loginbtn->Click += gcnew System::EventHandler(this, &Form1::Loginbtn_Click);
			// 
			// PasswordTxt
			// 
			this->PasswordTxt->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->PasswordTxt->Location = System::Drawing::Point(305, 273);
			this->PasswordTxt->MaxLength = 16;
			this->PasswordTxt->Name = L"PasswordTxt";
			this->PasswordTxt->Size = System::Drawing::Size(151, 24);
			this->PasswordTxt->TabIndex = 7;
			this->PasswordTxt->UseSystemPasswordChar = true;
			// 
			// UsernameTxt
			// 
			this->UsernameTxt->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->UsernameTxt->Location = System::Drawing::Point(305, 222);
			this->UsernameTxt->MaxLength = 30;
			this->UsernameTxt->Name = L"UsernameTxt";
			this->UsernameTxt->Size = System::Drawing::Size(151, 24);
			this->UsernameTxt->TabIndex = 6;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->BackColor = System::Drawing::Color::Transparent;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label5->Location = System::Drawing::Point(302, 252);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(83, 18);
			this->label5->TabIndex = 5;
			this->label5->Text = L"Password";
			// 
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->BackColor = System::Drawing::Color::Transparent;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(302, 200);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(85, 18);
			this->label4->TabIndex = 4;
			this->label4->Text = L"Username";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->BackColor = System::Drawing::Color::Transparent;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(301, 151);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(69, 20);
			this->label3->TabIndex = 3;
			this->label3->Text = L"LOGIN ";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->BackColor = System::Drawing::SystemColors::ActiveBorder;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(281, 535);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(251, 20);
			this->label2->TabIndex = 2;
			this->label2->Text = L"2021 ALL RIGHT RESERVED";
			// 
			// student_page
			// 
			this->student_page->Controls->Add(this->student_page1);
			this->student_page->Controls->Add(this->student_page2);
			this->student_page->Controls->Add(this->panel1);
			this->student_page->Controls->Add(this->button2);
			this->student_page->Controls->Add(this->label8);
			this->student_page->Location = System::Drawing::Point(12, 35);
			this->student_page->Name = L"student_page";
			this->student_page->Size = System::Drawing::Size(760, 490);
			this->student_page->TabIndex = 3;
			// 
			// student_page1
			// 
			this->student_page1->BackColor = System::Drawing::SystemColors::ScrollBar;
			this->student_page1->Controls->Add(this->label7);
			this->student_page1->Controls->Add(this->comboBox2);
			this->student_page1->Controls->Add(this->label6);
			this->student_page1->Controls->Add(this->comboBox1);
			this->student_page1->Controls->Add(this->button3);
			this->student_page1->Location = System::Drawing::Point(4, 116);
			this->student_page1->Name = L"student_page1";
			this->student_page1->Size = System::Drawing::Size(754, 360);
			this->student_page1->TabIndex = 15;
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->BackColor = System::Drawing::Color::Transparent;
			this->label7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label7->Location = System::Drawing::Point(291, 95);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(71, 16);
			this->label7->TabIndex = 18;
			this->label7->Text = L"Prac Slot";
			// 
			// comboBox2
			// 
			this->comboBox2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->comboBox2->FormattingEnabled = true;
			this->comboBox2->Items->AddRange(gcnew cli::array< System::Object^  >(5) {
				L"Monday : 14:10 - 17:20", L"Tuesday: 14:10 - 17:20",
					L"Wednesday: 14:10 - 17:20", L"Thursday: 14:10 - 17:20", L"Friday: 14:10 - 17:20"
			});
			this->comboBox2->Location = System::Drawing::Point(294, 114);
			this->comboBox2->Name = L"comboBox2";
			this->comboBox2->Size = System::Drawing::Size(159, 24);
			this->comboBox2->TabIndex = 17;
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->BackColor = System::Drawing::Color::Transparent;
			this->label6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label6->Location = System::Drawing::Point(291, 34);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(57, 16);
			this->label6->TabIndex = 16;
			this->label6->Text = L"Prac Id";
			// 
			// comboBox1
			// 
			this->comboBox1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Items->AddRange(gcnew cli::array< System::Object^  >(7) {
				L"CS2 ", L"CS5", L"CS6", L"CO1", L"CO2", L"SS1",
					L"SS2"
			});
			this->comboBox1->Location = System::Drawing::Point(294, 53);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(159, 24);
			this->comboBox1->TabIndex = 10;
			// 
			// button3
			// 
			this->button3->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button3->Location = System::Drawing::Point(294, 330);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(151, 23);
			this->button3->TabIndex = 9;
			this->button3->Text = L"Submit";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &Form1::button3_Click);
			// 
			// student_page2
			// 
			this->student_page2->BackColor = System::Drawing::SystemColors::ScrollBar;
			this->student_page2->Controls->Add(this->label30);
			this->student_page2->Controls->Add(this->textBox11);
			this->student_page2->Controls->Add(this->dataGridView1);
			this->student_page2->Controls->Add(this->button9);
			this->student_page2->Location = System::Drawing::Point(15, 149);
			this->student_page2->Name = L"student_page2";
			this->student_page2->Size = System::Drawing::Size(754, 360);
			this->student_page2->TabIndex = 16;
			// 
			// label30
			// 
			this->label30->AutoSize = true;
			this->label30->BackColor = System::Drawing::Color::Transparent;
			this->label30->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label30->Location = System::Drawing::Point(98, 337);
			this->label30->Name = L"label30";
			this->label30->Size = System::Drawing::Size(76, 16);
			this->label30->TabIndex = 25;
			this->label30->Text = L"Project ID";
			// 
			// textBox11
			// 
			this->textBox11->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->textBox11->Location = System::Drawing::Point(177, 335);
			this->textBox11->Name = L"textBox11";
			this->textBox11->Size = System::Drawing::Size(100, 22);
			this->textBox11->TabIndex = 24;
			// 
			// dataGridView1
			// 
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView1->Location = System::Drawing::Point(17, 14);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->SelectionMode = System::Windows::Forms::DataGridViewSelectionMode::FullRowSelect;
			this->dataGridView1->Size = System::Drawing::Size(719, 314);
			this->dataGridView1->TabIndex = 23;
			// 
			// button9
			// 
			this->button9->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button9->Location = System::Drawing::Point(294, 334);
			this->button9->Name = L"button9";
			this->button9->Size = System::Drawing::Size(151, 23);
			this->button9->TabIndex = 9;
			this->button9->Text = L"Select Project";
			this->button9->UseVisualStyleBackColor = true;
			this->button9->Click += gcnew System::EventHandler(this, &Form1::button9_Click);
			// 
			// panel1
			// 
			this->panel1->BackColor = System::Drawing::SystemColors::ScrollBar;
			this->panel1->Controls->Add(this->button8);
			this->panel1->Controls->Add(this->button7);
			this->panel1->Controls->Add(this->button5);
			this->panel1->Controls->Add(this->button6);
			this->panel1->Controls->Add(this->button4);
			this->panel1->Location = System::Drawing::Point(3, 47);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(754, 63);
			this->panel1->TabIndex = 14;
			// 
			// button8
			// 
			this->button8->BackColor = System::Drawing::Color::Transparent;
			this->button8->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button8->ForeColor = System::Drawing::Color::DarkRed;
			this->button8->Location = System::Drawing::Point(162, 18);
			this->button8->Name = L"button8";
			this->button8->Size = System::Drawing::Size(139, 32);
			this->button8->TabIndex = 19;
			this->button8->Text = L"Practical Booking";
			this->button8->UseVisualStyleBackColor = false;
			this->button8->Click += gcnew System::EventHandler(this, &Form1::button8_Click);
			// 
			// button7
			// 
			this->button7->BackColor = System::Drawing::Color::Transparent;
			this->button7->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button7->ForeColor = System::Drawing::Color::DarkRed;
			this->button7->Location = System::Drawing::Point(597, 18);
			this->button7->Name = L"button7";
			this->button7->Size = System::Drawing::Size(139, 32);
			this->button7->TabIndex = 18;
			this->button7->Text = L"Submit Project";
			this->button7->UseVisualStyleBackColor = false;
			// 
			// button5
			// 
			this->button5->BackColor = System::Drawing::Color::Transparent;
			this->button5->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button5->ForeColor = System::Drawing::Color::DarkRed;
			this->button5->Location = System::Drawing::Point(307, 18);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(139, 32);
			this->button5->TabIndex = 16;
			this->button5->Text = L"Project Selection";
			this->button5->UseVisualStyleBackColor = false;
			this->button5->Click += gcnew System::EventHandler(this, &Form1::button5_Click);
			// 
			// button6
			// 
			this->button6->BackColor = System::Drawing::Color::Transparent;
			this->button6->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button6->ForeColor = System::Drawing::Color::DarkRed;
			this->button6->Location = System::Drawing::Point(452, 18);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(139, 32);
			this->button6->TabIndex = 17;
			this->button6->Text = L"Project Marks";
			this->button6->UseVisualStyleBackColor = false;
			this->button6->Click += gcnew System::EventHandler(this, &Form1::button6_Click);
			// 
			// button4
			// 
			this->button4->BackColor = System::Drawing::Color::Transparent;
			this->button4->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button4->ForeColor = System::Drawing::Color::DarkRed;
			this->button4->Location = System::Drawing::Point(17, 18);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(139, 32);
			this->button4->TabIndex = 15;
			this->button4->Text = L"View Timetable";
			this->button4->UseVisualStyleBackColor = false;
			this->button4->Click += gcnew System::EventHandler(this, &Form1::button4_Click);
			// 
			// button2
			// 
			this->button2->BackColor = System::Drawing::Color::Transparent;
			this->button2->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button2->ForeColor = System::Drawing::Color::DarkRed;
			this->button2->Location = System::Drawing::Point(680, 3);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(77, 23);
			this->button2->TabIndex = 9;
			this->button2->Text = L"Log out";
			this->button2->UseVisualStyleBackColor = false;
			this->button2->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->BackColor = System::Drawing::Color::Transparent;
			this->label8->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label8->Location = System::Drawing::Point(311, 11);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(138, 16);
			this->label8->TabIndex = 3;
			this->label8->Text = L"STUDENT BOARD";
			// 
			// lecturer_page
			// 
			this->lecturer_page->Controls->Add(this->lecturer_page3);
			this->lecturer_page->Controls->Add(this->lecturer_page2);
			this->lecturer_page->Controls->Add(this->lecturer_page1);
			this->lecturer_page->Controls->Add(this->panel4);
			this->lecturer_page->Controls->Add(this->button16);
			this->lecturer_page->Controls->Add(this->label11);
			this->lecturer_page->Location = System::Drawing::Point(12, 38);
			this->lecturer_page->Name = L"lecturer_page";
			this->lecturer_page->Size = System::Drawing::Size(760, 490);
			this->lecturer_page->TabIndex = 17;
			// 
			// lecturer_page3
			// 
			this->lecturer_page3->BackColor = System::Drawing::SystemColors::ScrollBar;
			this->lecturer_page3->Controls->Add(this->label28);
			this->lecturer_page3->Controls->Add(this->label27);
			this->lecturer_page3->Controls->Add(this->textBox17);
			this->lecturer_page3->Controls->Add(this->textBox16);
			this->lecturer_page3->Controls->Add(this->comboBox3);
			this->lecturer_page3->Controls->Add(this->button21);
			this->lecturer_page3->Controls->Add(this->label23);
			this->lecturer_page3->Controls->Add(this->label24);
			this->lecturer_page3->Controls->Add(this->label25);
			this->lecturer_page3->Controls->Add(this->textBox13);
			this->lecturer_page3->Controls->Add(this->textBox14);
			this->lecturer_page3->Controls->Add(this->label26);
			this->lecturer_page3->Controls->Add(this->textBox15);
			this->lecturer_page3->Controls->Add(this->dataGridView4);
			this->lecturer_page3->Controls->Add(this->button14);
			this->lecturer_page3->Location = System::Drawing::Point(8, 121);
			this->lecturer_page3->Name = L"lecturer_page3";
			this->lecturer_page3->Size = System::Drawing::Size(754, 360);
			this->lecturer_page3->TabIndex = 17;
			// 
			// label28
			// 
			this->label28->AutoSize = true;
			this->label28->BackColor = System::Drawing::Color::Transparent;
			this->label28->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label28->Location = System::Drawing::Point(8, 252);
			this->label28->Name = L"label28";
			this->label28->Size = System::Drawing::Size(74, 13);
			this->label28->TabIndex = 34;
			this->label28->Text = L"Practical ID";
			// 
			// label27
			// 
			this->label27->AutoSize = true;
			this->label27->BackColor = System::Drawing::Color::Transparent;
			this->label27->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label27->Location = System::Drawing::Point(7, 52);
			this->label27->Name = L"label27";
			this->label27->Size = System::Drawing::Size(74, 13);
			this->label27->TabIndex = 33;
			this->label27->Text = L"Practical ID";
			// 
			// textBox17
			// 
			this->textBox17->Location = System::Drawing::Point(11, 142);
			this->textBox17->Name = L"textBox17";
			this->textBox17->Size = System::Drawing::Size(127, 20);
			this->textBox17->TabIndex = 32;
			// 
			// textBox16
			// 
			this->textBox16->Location = System::Drawing::Point(10, 268);
			this->textBox16->Name = L"textBox16";
			this->textBox16->Size = System::Drawing::Size(127, 20);
			this->textBox16->TabIndex = 31;
			// 
			// comboBox3
			// 
			this->comboBox3->FormattingEnabled = true;
			this->comboBox3->Items->AddRange(gcnew cli::array< System::Object^  >(5) {
				L"Monday @14:10-17:20", L"Tuesday @14:10-17:20",
					L"Wednesday @14:10-17:20", L"Thursday @14:10-17:20", L"Friday @14:10-17:20"
			});
			this->comboBox3->Location = System::Drawing::Point(10, 175);
			this->comboBox3->Name = L"comboBox3";
			this->comboBox3->Size = System::Drawing::Size(127, 21);
			this->comboBox3->TabIndex = 30;
			// 
			// button21
			// 
			this->button21->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button21->Location = System::Drawing::Point(10, 205);
			this->button21->Name = L"button21";
			this->button21->Size = System::Drawing::Size(127, 23);
			this->button21->TabIndex = 29;
			this->button21->Text = L"Add Practical";
			this->button21->UseVisualStyleBackColor = true;
			this->button21->Click += gcnew System::EventHandler(this, &Form1::button21_Click);
			// 
			// label23
			// 
			this->label23->AutoSize = true;
			this->label23->BackColor = System::Drawing::Color::Transparent;
			this->label23->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label23->Location = System::Drawing::Point(7, 163);
			this->label23->Name = L"label23";
			this->label23->Size = System::Drawing::Size(29, 13);
			this->label23->TabIndex = 28;
			this->label23->Text = L"Slot";
			// 
			// label24
			// 
			this->label24->AutoSize = true;
			this->label24->BackColor = System::Drawing::Color::Transparent;
			this->label24->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label24->Location = System::Drawing::Point(7, 126);
			this->label24->Name = L"label24";
			this->label24->Size = System::Drawing::Size(90, 13);
			this->label24->TabIndex = 27;
			this->label24->Text = L"Practical Tittle";
			// 
			// label25
			// 
			this->label25->AutoSize = true;
			this->label25->BackColor = System::Drawing::Color::Transparent;
			this->label25->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label25->Location = System::Drawing::Point(7, 91);
			this->label25->Name = L"label25";
			this->label25->Size = System::Drawing::Size(93, 13);
			this->label25->TabIndex = 26;
			this->label25->Text = L"Practical Name";
			// 
			// textBox13
			// 
			this->textBox13->Location = System::Drawing::Point(9, 29);
			this->textBox13->Name = L"textBox13";
			this->textBox13->Size = System::Drawing::Size(127, 20);
			this->textBox13->TabIndex = 25;
			// 
			// textBox14
			// 
			this->textBox14->Location = System::Drawing::Point(10, 69);
			this->textBox14->Name = L"textBox14";
			this->textBox14->Size = System::Drawing::Size(127, 20);
			this->textBox14->TabIndex = 24;
			// 
			// label26
			// 
			this->label26->AutoSize = true;
			this->label26->BackColor = System::Drawing::Color::Transparent;
			this->label26->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label26->Location = System::Drawing::Point(7, 13);
			this->label26->Name = L"label26";
			this->label26->Size = System::Drawing::Size(84, 13);
			this->label26->TabIndex = 23;
			this->label26->Text = L"Module Name";
			// 
			// textBox15
			// 
			this->textBox15->Location = System::Drawing::Point(11, 103);
			this->textBox15->Name = L"textBox15";
			this->textBox15->Size = System::Drawing::Size(127, 20);
			this->textBox15->TabIndex = 22;
			// 
			// dataGridView4
			// 
			this->dataGridView4->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView4->Location = System::Drawing::Point(143, 3);
			this->dataGridView4->Name = L"dataGridView4";
			this->dataGridView4->Size = System::Drawing::Size(619, 354);
			this->dataGridView4->TabIndex = 10;
			// 
			// button14
			// 
			this->button14->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button14->Location = System::Drawing::Point(10, 291);
			this->button14->Name = L"button14";
			this->button14->Size = System::Drawing::Size(127, 23);
			this->button14->TabIndex = 9;
			this->button14->Text = L"Delete Practical";
			this->button14->UseVisualStyleBackColor = true;
			this->button14->Click += gcnew System::EventHandler(this, &Form1::button14_Click);
			// 
			// lecturer_page2
			// 
			this->lecturer_page2->BackColor = System::Drawing::SystemColors::ScrollBar;
			this->lecturer_page2->Controls->Add(this->comboBox5);
			this->lecturer_page2->Controls->Add(this->label29);
			this->lecturer_page2->Controls->Add(this->textBox10);
			this->lecturer_page2->Controls->Add(this->richTextBox1);
			this->lecturer_page2->Controls->Add(this->comboBox4);
			this->lecturer_page2->Controls->Add(this->label20);
			this->lecturer_page2->Controls->Add(this->label21);
			this->lecturer_page2->Controls->Add(this->label22);
			this->lecturer_page2->Controls->Add(this->label19);
			this->lecturer_page2->Controls->Add(this->textBox9);
			this->lecturer_page2->Controls->Add(this->label18);
			this->lecturer_page2->Controls->Add(this->textBox8);
			this->lecturer_page2->Controls->Add(this->button18);
			this->lecturer_page2->Controls->Add(this->label17);
			this->lecturer_page2->Controls->Add(this->textBox7);
			this->lecturer_page2->Controls->Add(this->dataGridView3);
			this->lecturer_page2->Controls->Add(this->button12);
			this->lecturer_page2->Location = System::Drawing::Point(4, 120);
			this->lecturer_page2->Name = L"lecturer_page2";
			this->lecturer_page2->Size = System::Drawing::Size(754, 360);
			this->lecturer_page2->TabIndex = 16;
			// 
			// comboBox5
			// 
			this->comboBox5->FormattingEnabled = true;
			this->comboBox5->Items->AddRange(gcnew cli::array< System::Object^  >(3) { L"CE", L"EC", L"EL" });
			this->comboBox5->Location = System::Drawing::Point(16, 134);
			this->comboBox5->Name = L"comboBox5";
			this->comboBox5->Size = System::Drawing::Size(127, 21);
			this->comboBox5->TabIndex = 35;
			// 
			// label29
			// 
			this->label29->AutoSize = true;
			this->label29->BackColor = System::Drawing::Color::Transparent;
			this->label29->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label29->Location = System::Drawing::Point(243, 339);
			this->label29->Name = L"label29";
			this->label29->Size = System::Drawing::Size(64, 13);
			this->label29->TabIndex = 34;
			this->label29->Text = L"Project ID";
			// 
			// textBox10
			// 
			this->textBox10->Location = System::Drawing::Point(313, 334);
			this->textBox10->Name = L"textBox10";
			this->textBox10->Size = System::Drawing::Size(127, 20);
			this->textBox10->TabIndex = 33;
			// 
			// richTextBox1
			// 
			this->richTextBox1->Location = System::Drawing::Point(16, 220);
			this->richTextBox1->Name = L"richTextBox1";
			this->richTextBox1->Size = System::Drawing::Size(127, 105);
			this->richTextBox1->TabIndex = 32;
			this->richTextBox1->Text = L"";
			// 
			// comboBox4
			// 
			this->comboBox4->FormattingEnabled = true;
			this->comboBox4->Items->AddRange(gcnew cli::array< System::Object^  >(3) { L"Software", L"Hardware", L"Both Software & Hardware" });
			this->comboBox4->Location = System::Drawing::Point(16, 177);
			this->comboBox4->Name = L"comboBox4";
			this->comboBox4->Size = System::Drawing::Size(127, 21);
			this->comboBox4->TabIndex = 31;
			// 
			// label20
			// 
			this->label20->AutoSize = true;
			this->label20->BackColor = System::Drawing::Color::Transparent;
			this->label20->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label20->Location = System::Drawing::Point(13, 203);
			this->label20->Name = L"label20";
			this->label20->Size = System::Drawing::Size(120, 13);
			this->label20->TabIndex = 23;
			this->label20->Text = L"Problem Description";
			// 
			// label21
			// 
			this->label21->AutoSize = true;
			this->label21->BackColor = System::Drawing::Color::Transparent;
			this->label21->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label21->Location = System::Drawing::Point(13, 121);
			this->label21->Name = L"label21";
			this->label21->Size = System::Drawing::Size(57, 13);
			this->label21->TabIndex = 21;
			this->label21->Text = L"Eligibility";
			// 
			// label22
			// 
			this->label22->AutoSize = true;
			this->label22->BackColor = System::Drawing::Color::Transparent;
			this->label22->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label22->Location = System::Drawing::Point(13, 84);
			this->label22->Name = L"label22";
			this->label22->Size = System::Drawing::Size(103, 13);
			this->label22->TabIndex = 19;
			this->label22->Text = L"Supervisor Name";
			// 
			// label19
			// 
			this->label19->AutoSize = true;
			this->label19->BackColor = System::Drawing::Color::Transparent;
			this->label19->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label19->Location = System::Drawing::Point(13, 49);
			this->label19->Name = L"label19";
			this->label19->Size = System::Drawing::Size(80, 13);
			this->label19->TabIndex = 17;
			this->label19->Text = L"Project Tittle";
			// 
			// textBox9
			// 
			this->textBox9->Location = System::Drawing::Point(16, 99);
			this->textBox9->Name = L"textBox9";
			this->textBox9->Size = System::Drawing::Size(127, 20);
			this->textBox9->TabIndex = 16;
			// 
			// label18
			// 
			this->label18->AutoSize = true;
			this->label18->BackColor = System::Drawing::Color::Transparent;
			this->label18->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label18->Location = System::Drawing::Point(13, 161);
			this->label18->Name = L"label18";
			this->label18->Size = System::Drawing::Size(92, 13);
			this->label18->TabIndex = 15;
			this->label18->Text = L"Implementation";
			// 
			// textBox8
			// 
			this->textBox8->Location = System::Drawing::Point(16, 63);
			this->textBox8->Name = L"textBox8";
			this->textBox8->Size = System::Drawing::Size(127, 20);
			this->textBox8->TabIndex = 14;
			// 
			// button18
			// 
			this->button18->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button18->Location = System::Drawing::Point(448, 334);
			this->button18->Name = L"button18";
			this->button18->Size = System::Drawing::Size(151, 23);
			this->button18->TabIndex = 13;
			this->button18->Text = L"Remove Project";
			this->button18->UseVisualStyleBackColor = true;
			this->button18->Click += gcnew System::EventHandler(this, &Form1::button18_Click);
			// 
			// label17
			// 
			this->label17->AutoSize = true;
			this->label17->BackColor = System::Drawing::Color::Transparent;
			this->label17->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label17->Location = System::Drawing::Point(13, 9);
			this->label17->Name = L"label17";
			this->label17->Size = System::Drawing::Size(64, 13);
			this->label17->TabIndex = 12;
			this->label17->Text = L"Project ID";
			// 
			// textBox7
			// 
			this->textBox7->Location = System::Drawing::Point(16, 26);
			this->textBox7->Name = L"textBox7";
			this->textBox7->Size = System::Drawing::Size(127, 20);
			this->textBox7->TabIndex = 11;
			// 
			// dataGridView3
			// 
			this->dataGridView3->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView3->Location = System::Drawing::Point(149, 9);
			this->dataGridView3->Name = L"dataGridView3";
			this->dataGridView3->Size = System::Drawing::Size(601, 316);
			this->dataGridView3->TabIndex = 10;
			// 
			// button12
			// 
			this->button12->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button12->Location = System::Drawing::Point(16, 330);
			this->button12->Name = L"button12";
			this->button12->Size = System::Drawing::Size(127, 23);
			this->button12->TabIndex = 9;
			this->button12->Text = L"Add Project";
			this->button12->UseVisualStyleBackColor = true;
			this->button12->Click += gcnew System::EventHandler(this, &Form1::button12_Click);
			// 
			// lecturer_page1
			// 
			this->lecturer_page1->BackColor = System::Drawing::SystemColors::ScrollBar;
			this->lecturer_page1->Controls->Add(this->dataGridView2);
			this->lecturer_page1->Controls->Add(this->button10);
			this->lecturer_page1->Location = System::Drawing::Point(3, 116);
			this->lecturer_page1->Name = L"lecturer_page1";
			this->lecturer_page1->Size = System::Drawing::Size(754, 360);
			this->lecturer_page1->TabIndex = 15;
			// 
			// dataGridView2
			// 
			this->dataGridView2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView2->Location = System::Drawing::Point(3, 3);
			this->dataGridView2->Name = L"dataGridView2";
			this->dataGridView2->Size = System::Drawing::Size(748, 322);
			this->dataGridView2->TabIndex = 10;
			// 
			// button10
			// 
			this->button10->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button10->Location = System::Drawing::Point(294, 334);
			this->button10->Name = L"button10";
			this->button10->Size = System::Drawing::Size(151, 23);
			this->button10->TabIndex = 9;
			this->button10->Text = L"Submit";
			this->button10->UseVisualStyleBackColor = true;
			this->button10->Click += gcnew System::EventHandler(this, &Form1::button10_Click);
			// 
			// panel4
			// 
			this->panel4->BackColor = System::Drawing::SystemColors::ScrollBar;
			this->panel4->Controls->Add(this->button11);
			this->panel4->Controls->Add(this->button13);
			this->panel4->Controls->Add(this->button15);
			this->panel4->Location = System::Drawing::Point(1, 47);
			this->panel4->Name = L"panel4";
			this->panel4->Size = System::Drawing::Size(754, 63);
			this->panel4->TabIndex = 14;
			// 
			// button11
			// 
			this->button11->BackColor = System::Drawing::Color::Transparent;
			this->button11->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button11->ForeColor = System::Drawing::Color::DarkRed;
			this->button11->Location = System::Drawing::Point(277, 15);
			this->button11->Name = L"button11";
			this->button11->Size = System::Drawing::Size(139, 32);
			this->button11->TabIndex = 19;
			this->button11->Text = L"Project Management";
			this->button11->UseVisualStyleBackColor = false;
			this->button11->Click += gcnew System::EventHandler(this, &Form1::button11_Click);
			// 
			// button13
			// 
			this->button13->BackColor = System::Drawing::Color::Transparent;
			this->button13->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button13->ForeColor = System::Drawing::Color::DarkRed;
			this->button13->Location = System::Drawing::Point(422, 15);
			this->button13->Name = L"button13";
			this->button13->Size = System::Drawing::Size(139, 32);
			this->button13->TabIndex = 16;
			this->button13->Text = L"Project Marking";
			this->button13->UseVisualStyleBackColor = false;
			this->button13->Click += gcnew System::EventHandler(this, &Form1::button13_Click);
			// 
			// button15
			// 
			this->button15->BackColor = System::Drawing::Color::Transparent;
			this->button15->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button15->ForeColor = System::Drawing::Color::DarkRed;
			this->button15->Location = System::Drawing::Point(132, 15);
			this->button15->Name = L"button15";
			this->button15->Size = System::Drawing::Size(139, 32);
			this->button15->TabIndex = 15;
			this->button15->Text = L"Practical Management ";
			this->button15->UseVisualStyleBackColor = false;
			this->button15->Click += gcnew System::EventHandler(this, &Form1::button15_Click);
			// 
			// button16
			// 
			this->button16->BackColor = System::Drawing::Color::Transparent;
			this->button16->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button16->ForeColor = System::Drawing::Color::DarkRed;
			this->button16->Location = System::Drawing::Point(680, 3);
			this->button16->Name = L"button16";
			this->button16->Size = System::Drawing::Size(77, 23);
			this->button16->TabIndex = 9;
			this->button16->Text = L"Log out";
			this->button16->UseVisualStyleBackColor = false;
			this->button16->Click += gcnew System::EventHandler(this, &Form1::button16_Click);
			// 
			// label11
			// 
			this->label11->AutoSize = true;
			this->label11->BackColor = System::Drawing::Color::Transparent;
			this->label11->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label11->Location = System::Drawing::Point(311, 11);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(146, 16);
			this->label11->TabIndex = 3;
			this->label11->Text = L"LECTURER BOARD";
			// 
			// admin_page
			// 
			this->admin_page->Controls->Add(this->admin_page1);
			this->admin_page->Controls->Add(this->admin_page2);
			this->admin_page->Controls->Add(this->panel7);
			this->admin_page->Controls->Add(this->button23);
			this->admin_page->Controls->Add(this->label9);
			this->admin_page->Location = System::Drawing::Point(16, 37);
			this->admin_page->Name = L"admin_page";
			this->admin_page->Size = System::Drawing::Size(760, 490);
			this->admin_page->TabIndex = 18;
			this->admin_page->Paint += gcnew System::Windows::Forms::PaintEventHandler(this, &Form1::admin_page_Paint);
			// 
			// admin_page1
			// 
			this->admin_page1->BackColor = System::Drawing::SystemColors::ScrollBar;
			this->admin_page1->Controls->Add(this->textBox3);
			this->admin_page1->Controls->Add(this->label13);
			this->admin_page1->Controls->Add(this->textBox2);
			this->admin_page1->Controls->Add(this->label12);
			this->admin_page1->Controls->Add(this->textBox1);
			this->admin_page1->Controls->Add(this->label10);
			this->admin_page1->Controls->Add(this->button17);
			this->admin_page1->Location = System::Drawing::Point(10, 116);
			this->admin_page1->Name = L"admin_page1";
			this->admin_page1->Size = System::Drawing::Size(746, 360);
			this->admin_page1->TabIndex = 17;
			// 
			// textBox3
			// 
			this->textBox3->Location = System::Drawing::Point(366, 92);
			this->textBox3->Name = L"textBox3";
			this->textBox3->Size = System::Drawing::Size(217, 20);
			this->textBox3->TabIndex = 15;
			// 
			// label13
			// 
			this->label13->AutoSize = true;
			this->label13->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label13->Location = System::Drawing::Point(224, 93);
			this->label13->Name = L"label13";
			this->label13->Size = System::Drawing::Size(109, 20);
			this->label13->TabIndex = 14;
			this->label13->Text = L"Student Email";
			// 
			// textBox2
			// 
			this->textBox2->Location = System::Drawing::Point(366, 63);
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(217, 20);
			this->textBox2->TabIndex = 13;
			// 
			// label12
			// 
			this->label12->AutoSize = true;
			this->label12->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label12->Location = System::Drawing::Point(224, 63);
			this->label12->Name = L"label12";
			this->label12->Size = System::Drawing::Size(87, 20);
			this->label12->TabIndex = 12;
			this->label12->Text = L"Student ID";
			this->label12->Click += gcnew System::EventHandler(this, &Form1::label12_Click);
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(366, 31);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(217, 20);
			this->textBox1->TabIndex = 11;
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label10->Location = System::Drawing::Point(224, 32);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(112, 20);
			this->label10->TabIndex = 10;
			this->label10->Text = L"Student Name";
			// 
			// button17
			// 
			this->button17->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button17->Location = System::Drawing::Point(294, 334);
			this->button17->Name = L"button17";
			this->button17->Size = System::Drawing::Size(151, 23);
			this->button17->TabIndex = 9;
			this->button17->Text = L"Submit";
			this->button17->UseVisualStyleBackColor = true;
			this->button17->Click += gcnew System::EventHandler(this, &Form1::button17_Click);
			// 
			// admin_page2
			// 
			this->admin_page2->BackColor = System::Drawing::SystemColors::ScrollBar;
			this->admin_page2->Controls->Add(this->textBox4);
			this->admin_page2->Controls->Add(this->label14);
			this->admin_page2->Controls->Add(this->textBox5);
			this->admin_page2->Controls->Add(this->label15);
			this->admin_page2->Controls->Add(this->textBox6);
			this->admin_page2->Controls->Add(this->label16);
			this->admin_page2->Controls->Add(this->button19);
			this->admin_page2->Location = System::Drawing::Point(3, 116);
			this->admin_page2->Name = L"admin_page2";
			this->admin_page2->Size = System::Drawing::Size(754, 360);
			this->admin_page2->TabIndex = 15;
			// 
			// textBox4
			// 
			this->textBox4->Location = System::Drawing::Point(350, 41);
			this->textBox4->Name = L"textBox4";
			this->textBox4->Size = System::Drawing::Size(217, 20);
			this->textBox4->TabIndex = 21;
			// 
			// label14
			// 
			this->label14->AutoSize = true;
			this->label14->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label14->Location = System::Drawing::Point(208, 105);
			this->label14->Name = L"label14";
			this->label14->Size = System::Drawing::Size(87, 20);
			this->label14->TabIndex = 20;
			this->label14->Text = L"Stuff Email";
			// 
			// textBox5
			// 
			this->textBox5->Location = System::Drawing::Point(350, 73);
			this->textBox5->Name = L"textBox5";
			this->textBox5->Size = System::Drawing::Size(217, 20);
			this->textBox5->TabIndex = 19;
			// 
			// label15
			// 
			this->label15->AutoSize = true;
			this->label15->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label15->Location = System::Drawing::Point(208, 75);
			this->label15->Name = L"label15";
			this->label15->Size = System::Drawing::Size(65, 20);
			this->label15->TabIndex = 18;
			this->label15->Text = L"Stuff ID";
			// 
			// textBox6
			// 
			this->textBox6->Location = System::Drawing::Point(350, 101);
			this->textBox6->Name = L"textBox6";
			this->textBox6->Size = System::Drawing::Size(217, 20);
			this->textBox6->TabIndex = 17;
			// 
			// label16
			// 
			this->label16->AutoSize = true;
			this->label16->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label16->Location = System::Drawing::Point(208, 44);
			this->label16->Name = L"label16";
			this->label16->Size = System::Drawing::Size(90, 20);
			this->label16->TabIndex = 16;
			this->label16->Text = L"Stuff Name";
			// 
			// button19
			// 
			this->button19->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button19->Location = System::Drawing::Point(294, 334);
			this->button19->Name = L"button19";
			this->button19->Size = System::Drawing::Size(151, 23);
			this->button19->TabIndex = 9;
			this->button19->Text = L"Submit";
			this->button19->UseVisualStyleBackColor = true;
			this->button19->Click += gcnew System::EventHandler(this, &Form1::button19_Click);
			// 
			// panel7
			// 
			this->panel7->BackColor = System::Drawing::SystemColors::ScrollBar;
			this->panel7->Controls->Add(this->button20);
			this->panel7->Controls->Add(this->button22);
			this->panel7->Location = System::Drawing::Point(3, 47);
			this->panel7->Name = L"panel7";
			this->panel7->Size = System::Drawing::Size(754, 63);
			this->panel7->TabIndex = 14;
			// 
			// button20
			// 
			this->button20->BackColor = System::Drawing::Color::Transparent;
			this->button20->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button20->ForeColor = System::Drawing::Color::DarkRed;
			this->button20->Location = System::Drawing::Point(374, 16);
			this->button20->Name = L"button20";
			this->button20->Size = System::Drawing::Size(139, 32);
			this->button20->TabIndex = 19;
			this->button20->Text = L"Stuff Registration";
			this->button20->UseVisualStyleBackColor = false;
			this->button20->Click += gcnew System::EventHandler(this, &Form1::button20_Click);
			// 
			// button22
			// 
			this->button22->BackColor = System::Drawing::Color::Transparent;
			this->button22->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button22->ForeColor = System::Drawing::Color::DarkRed;
			this->button22->Location = System::Drawing::Point(205, 15);
			this->button22->Name = L"button22";
			this->button22->Size = System::Drawing::Size(139, 32);
			this->button22->TabIndex = 15;
			this->button22->Text = L"Student Registration";
			this->button22->UseVisualStyleBackColor = false;
			this->button22->Click += gcnew System::EventHandler(this, &Form1::button22_Click);
			// 
			// button23
			// 
			this->button23->BackColor = System::Drawing::Color::Transparent;
			this->button23->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button23->ForeColor = System::Drawing::Color::DarkRed;
			this->button23->Location = System::Drawing::Point(680, 3);
			this->button23->Name = L"button23";
			this->button23->Size = System::Drawing::Size(77, 23);
			this->button23->TabIndex = 9;
			this->button23->Text = L"Log out";
			this->button23->UseVisualStyleBackColor = false;
			this->button23->Click += gcnew System::EventHandler(this, &Form1::button23_Click);
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->BackColor = System::Drawing::Color::Transparent;
			this->label9->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label9->Location = System::Drawing::Point(311, 11);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(113, 16);
			this->label9->TabIndex = 3;
			this->label9->Text = L"ADMIN BOARD";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(784, 561);
			this->Controls->Add(this->admin_page);
			this->Controls->Add(this->lecturer_page);
			this->Controls->Add(this->student_page);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->login_page);
			this->Controls->Add(this->label1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::None;
			this->Name = L"Form1";
			this->Text = L"UKZN ENGINEERING STUDENT SYSTEM";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->login_page->ResumeLayout(false);
			this->login_page->PerformLayout();
			this->student_page->ResumeLayout(false);
			this->student_page->PerformLayout();
			this->student_page1->ResumeLayout(false);
			this->student_page1->PerformLayout();
			this->student_page2->ResumeLayout(false);
			this->student_page2->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->EndInit();
			this->panel1->ResumeLayout(false);
			this->lecturer_page->ResumeLayout(false);
			this->lecturer_page->PerformLayout();
			this->lecturer_page3->ResumeLayout(false);
			this->lecturer_page3->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView4))->EndInit();
			this->lecturer_page2->ResumeLayout(false);
			this->lecturer_page2->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView3))->EndInit();
			this->lecturer_page1->ResumeLayout(false);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView2))->EndInit();
			this->panel4->ResumeLayout(false);
			this->admin_page->ResumeLayout(false);
			this->admin_page->PerformLayout();
			this->admin_page1->ResumeLayout(false);
			this->admin_page1->PerformLayout();
			this->admin_page2->ResumeLayout(false);
			this->admin_page2->PerformLayout();
			this->panel7->ResumeLayout(false);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
		//methods
private: System::Void Book_Practical()
{
	if (String::IsNullOrEmpty(comboBox1->Text) || String::IsNullOrEmpty(comboBox2->Text))
	{
		MessageBox::Show("Please Fill Empty Spaces");
	}
	else
	{
		String^ Str = "Server = 127.0.0.1; Uid = root; Pwd = ; Database = ukzneng_stusystem";
		MySqlConnection^ connection = gcnew MySqlConnection(Str); 
		{
			MySqlCommand^ command = gcnew MySqlCommand("select * from practical_bookings where practical_id = '" + this->comboBox1->Text + "' ;", connection);
			MySqlDataReader^ dr;
			try
			{
				connection->Open();
				dr = command->ExecuteReader();
				int c = 0;
				while (dr->Read())
				{
					c++;
				}
				if (c != 1)
				{
					MySqlConnection^ connection2 = gcnew MySqlConnection(Str); 
					MySqlCommand^ command2 = gcnew MySqlCommand("select * FROM practical_slot where practical_id='" + comboBox1->Text + "'; ", connection2);
					MySqlDataReader^ dr;
					try {
						connection2->Open();
						dr = command2->ExecuteReader();
						int c = 0;
						while (dr->Read())
						{
							c++;
						}
						if (c != 1)
						{
							MessageBox::Show("Could not obtain data!");
						}
						else
						{
							String^ prac_name = dr["prac_name"]->ToString();
							String^ module = dr["module"]->ToString();

							MySqlConnection^ connection3 = gcnew MySqlConnection(Str);
							try
							{

								MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO practical_bookings (module, student_id, practical_id, practical_name, time) VALUES ('" + module + "','" + UsernameTxt->Text + "','" + comboBox1->Text + "','" + prac_name + "', '" + comboBox2->Text + "')", connection3);
								MySqlDataReader^ dr;
								connection3->Open();
								dr = cmd->ExecuteReader();

								MessageBox::Show("Practical  Booked");
								comboBox1->Items->Clear();//clear 
								comboBox2->Items->Clear();//clear
							}
							catch (Exception^ ex)
							{
								MessageBox::Show(ex->Message);
							}
						}

					}
					catch (Exception^ ex)
					{
						MessageBox::Show(ex->Message);
					}
				}
				else
				{
					MessageBox::Show("Practical Already booked");
				}
			}
			catch (Exception^ ex)
			{
				MessageBox::Show(ex->Message);
			}
		}


	}
}

//View marks():
private: System::Void AddSelected()
{
	{
		String^ Str = "Server = 127.0.0.1; Uid = root; Pwd = ; Database = ukzneng_stusystem";
		MySqlConnection^ connection = gcnew MySqlConnection(Str);
		{
			MySqlCommand^ command = gcnew MySqlCommand("select * from projects_table where project_id = '" + this->textBox11->Text + "';", connection);
			MySqlDataReader^ dr;
			try
			{
				connection->Open();
				dr = command->ExecuteReader();
				int c = 0;
				while (dr->Read())
				{
					c++;
				}
				if (c != 1) 
				{
					MessageBox::Show("This project is not available!");

					//
				}

				else
				{
					MySqlConnection^ connection3 = gcnew MySqlConnection(Str);
					try
					{

						String^ project_tittle = dr["project_tittle"]->ToString();
						String^ lecturer_name = dr["lecturer_name"]->ToString();

						MySqlConnection^ connection3 = gcnew MySqlConnection(Str);
						try
						{

							MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO project_allocations (student_id, project_id,project_name, supervisor_name) VALUES ('" + UsernameTxt->Text + "','" + textBox11->Text + "','" + project_tittle + "','" + lecturer_name + "')", connection3);
							MySqlDataReader^ dr;
							connection3->Open();
							dr = cmd->ExecuteReader();

							MessageBox::Show("Project  Selected");
							comboBox1->Items->Clear();//clear 
							comboBox2->Items->Clear();//clear
						}
						catch (Exception^ ex)
						{
							MessageBox::Show(ex->Message);
						}
					}
					catch (Exception^ ex)
					{
						MessageBox::Show(ex->Message);
					}
				}
			}
			catch (Exception^ ex)
			{
				MessageBox::Show(ex->Message);

			}
		}
	}
}

//AddSelected():
private: System::Void ProjectMarks()
{
	{
		String^ Str = "Server = 127.0.0.1; Uid = root; Pwd = ; Database = ukzneng_stusystem";
		MySqlConnection^ connection = gcnew MySqlConnection(Str);
		{
			MySqlCommand^ command = gcnew MySqlCommand("select * from project_marks where student_id = '" + this->UsernameTxt->Text + "';", connection);
			MySqlDataReader^ dr;
			try
			{
				MySqlDataAdapter^ sda = gcnew MySqlDataAdapter();
				sda->SelectCommand = command;
				DataTable^ dbdataset = gcnew DataTable();
				sda->Fill(dbdataset);
				BindingSource^ bSource = gcnew BindingSource();

				bSource->DataSource = dbdataset;
				dataGridView1->DataSource = bSource;
				sda->Update(dbdataset);
			}
			catch (Exception^ ex)
			{
				MessageBox::Show(ex->Message);
			}
		}
	}
}


	   //DataBinding();
private: System::Void DataBinding()
{
	{
		String^ Str = "Server = 127.0.0.1; Uid = root; Pwd = ; Database = ukzneng_stusystem";
		MySqlConnection^ connection = gcnew MySqlConnection(Str);
		{
			MySqlCommand^ command = gcnew MySqlCommand("select * from projects_table;", connection);
			MySqlDataReader^ dr;
			try
			{
				MySqlDataAdapter^ sda = gcnew MySqlDataAdapter();
				sda->SelectCommand = command;
				DataTable^ dbdataset = gcnew DataTable();
				sda->Fill(dbdataset);
				BindingSource^ bSource = gcnew BindingSource();

				bSource->DataSource = dbdataset;
				dataGridView1->DataSource = bSource;
				sda->Update(dbdataset);
			}
			catch (Exception^ ex)
			{
				MessageBox::Show(ex->Message);
			}
		}
	}
}

	   //PracticalManagement
private: System::Void PracticalManagement()
{
	{
		String^ Str = "Server = 127.0.0.1; Uid = root; Pwd = ; Database = ukzneng_stusystem";
		MySqlConnection^ connection = gcnew MySqlConnection(Str);
		{
			MySqlCommand^ command = gcnew MySqlCommand("select * from practical_slot;", connection);
			MySqlDataReader^ dr;
			try
			{
				MySqlDataAdapter^ sda = gcnew MySqlDataAdapter();
				sda->SelectCommand = command;
				DataTable^ dbdataset = gcnew DataTable();
				sda->Fill(dbdataset);
				BindingSource^ bSource = gcnew BindingSource();

				bSource->DataSource = dbdataset;
				dataGridView4->DataSource = bSource;
				sda->Update(dbdataset);
			}
			catch (Exception^ ex)
			{
				MessageBox::Show(ex->Message);
			}
		}
	}
}

	   //PracticalManagement
private: System::Void ProjectManagement()
{
	{
		String^ Str = "Server = 127.0.0.1; Uid = root; Pwd = ; Database = ukzneng_stusystem";
		MySqlConnection^ connection = gcnew MySqlConnection(Str);
		{
			MySqlCommand^ command = gcnew MySqlCommand("select * from projects_table;", connection);
			MySqlDataReader^ dr;
			try
			{
				MySqlDataAdapter^ sda = gcnew MySqlDataAdapter();
				sda->SelectCommand = command;
				DataTable^ dbdataset = gcnew DataTable();
				sda->Fill(dbdataset);
				BindingSource^ bSource = gcnew BindingSource();

				bSource->DataSource = dbdataset;
				dataGridView3->DataSource = bSource;
				sda->Update(dbdataset);
			}
			catch (Exception^ ex)
			{
				MessageBox::Show(ex->Message);
			}
		}
	}
}

	   //Markings
private: System::Void Markings()
{
	{
		String^ Str = "Server = 127.0.0.1; Uid = root; Pwd = ; Database = ukzneng_stusystem";
		MySqlConnection^ connection = gcnew MySqlConnection(Str);
		{
			MySqlCommand^ command = gcnew MySqlCommand("select * from project_marks;", connection);
			MySqlDataReader^ dr;
			try
			{
				MySqlDataAdapter^ sda = gcnew MySqlDataAdapter();
				sda->SelectCommand = command;
				DataTable^ dbdataset = gcnew DataTable();
				sda->Fill(dbdataset);
				BindingSource^ bSource = gcnew BindingSource();

				bSource->DataSource = dbdataset;
				dataGridView2->DataSource = bSource;
				sda->Update(dbdataset);
			}
			catch (Exception^ ex)
			{
				MessageBox::Show(ex->Message);
			}
		}
	}
}

private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
		//quit application
		Application::Exit();
	}
private: System::Void Loginbtn_Click(System::Object^ sender, System::EventArgs^ e) {
	//user identification
	//User method
	UserIdentification();

}

	   //User identification
private: System::Void UserIdentification()
	   {
		   String^ Str = "Server = 127.0.0.1; Uid = root; Pwd = ; Database = ukzneng_stusystem";//server
		   MySqlConnection^ connection = gcnew MySqlConnection(Str);  //mySql connection

		   MySqlCommand^ command = gcnew MySqlCommand("select * from all_members where id = '" + this->UsernameTxt->Text + "' and password = '" + this->PasswordTxt->Text + "';", connection);
		   MySqlDataReader^ dr;
		   try 
		   {
			   connection->Open();
			   dr = command->ExecuteReader();
			   int c = 0;
			   while (dr->Read())
			   {
				   c++;
			   }
			   if (c != 1) {
				   MessageBox::Show("Access denied !");
				   UsernameTxt->Clear();//clear 
				   PasswordTxt->Clear();//clear 
			   }

			   else
			   {
				   MessageBox::Show("Access Granted!");
				   // switch panels
				   if (dr["member_group"]->ToString() == "student")
				   {
					   //redirect to student page
					   this->login_page->Visible = false;
					   // this->administration_page->Visible = false;
						this->student_page->Visible = true;
					   // this->lecture_page->Visible = false;
				   }
				   else if (dr["member_group"]->ToString() == "lecturer")
				   {
					   //redirect to lecturer page
					   PracticalManagement();
					   this->login_page->Visible = false;
					   this->student_page1->Visible = false;
					   this->student_page->Visible = false;
					   this->student_page2->Visible = false;
					   this->lecturer_page->Visible = true;
					   this->lecturer_page1->Visible = true;
					   this->lecturer_page2->Visible = false;
					   this->lecturer_page3->Visible = false;


				   }
				   else if (dr["member_group"]->ToString() == "administrator")
				   {
					   //redirect to student page
					   //PracticalManagement();
					   this->login_page->Visible = false;
					   this->student_page1->Visible = false;
					   this->student_page->Visible = false;
					   this->student_page2->Visible = false;
					   this->lecturer_page->Visible = false;
					   this->lecturer_page1->Visible = false;
					   this->lecturer_page2->Visible = false;
					   this->lecturer_page3->Visible = false;

					   this->admin_page->Visible = true;
					   this->admin_page1->Visible = true;
					   this->admin_page2->Visible = false;

					   // this->administration_page->Visible = false;
						//this->student_page->Visible = true;
					   // this->lecture_page->Visible = false;
				   }
				   else
				   {
					   MessageBox::Show("Unauthorized access !!!");
					   //redirect to student page
					   this->login_page->Visible = true;
					   this->login_page->Visible = false;
					   this->student_page1->Visible = false;
					   this->student_page->Visible = false;
					   this->student_page2->Visible = false;
					   this->lecturer_page->Visible = false;
					   this->lecturer_page1->Visible = false;
					   this->lecturer_page2->Visible = false;
					   this->lecturer_page3->Visible = false;

					   // this->administration_page->Visible = false;
						//this->student_page->Visible = true;
					   // this->lecture_page->Visible = false;	

				   }


			   }
		   }
		   catch (Exception^ ex)
		   {
			   MessageBox::Show(ex->Message);
		   }
	   }//end of User
private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) {
	//SIGN OUT
	//redirect to student page
	this->login_page->Visible = true;
	// this->administration_page->Visible = false;
	 this->student_page->Visible = false;
	// this->lecture_page->Visible = false;	

}
private: System::Void button3_Click(System::Object^ sender, System::EventArgs^ e) {
	//student page 1 
	//textbox 11

	Book_Practical();
}
private: System::Void Form1_Load(System::Object^ sender, System::EventArgs^ e) {
	//
	this->login_page->Visible = true;
	this->student_page1->Visible = false;
	this->student_page2->Visible = false;
	this->lecturer_page->Visible = false;
	this->lecturer_page1->Visible = false;
	this->lecturer_page2->Visible = false;
	this->admin_page->Visible = false;
	this->admin_page1->Visible = false;
	this->admin_page2->Visible = false;



  // this->administration_page->Visible = false;
	 this->student_page->Visible = false;
	// this->lecture_page->Visible = false;	
}
private: System::Void button4_Click(System::Object^ sender, System::EventArgs^ e) {
	System::Diagnostics::Process::Start("https://celcatwp.ukzn.ac.za/2021/HOWARDCOLLEGE/COMPENGSEM2/finder.html");

}
private: System::Void button5_Click(System::Object^ sender, System::EventArgs^ e) {
//retrieve data from database
	this->student_page2->Visible = false;

	DataBinding();
	this->student_page1->Visible = false;
	this->student_page2->Visible = true;



}
private: System::Void button8_Click(System::Object^ sender, System::EventArgs^ e) {
	//
	this->student_page1->Visible = true;
	this->student_page2->Visible = false;
}
private: System::Void button9_Click(System::Object^ sender, System::EventArgs^ e) {
	//save project
	AddSelected();

}
private: System::Void button6_Click(System::Object^ sender, System::EventArgs^ e) {
	//view marks
	ProjectMarks();
	this->student_page1->Visible = false;
	this->student_page2->Visible = false;

}
private: System::Void button10_Click(System::Object^ sender, System::EventArgs^ e) {
	//datagrid2
	//lecture_page1
	PracticalManagement();
}
private: System::Void button12_Click(System::Object^ sender, System::EventArgs^ e) {
	//textbox 7,8,8, 12
	// //combobox 4
	// //rich field 1
	//project management
	AddProject();


}
private: System::Void button15_Click(System::Object^ sender, System::EventArgs^ e) {
	//pracs
	PracticalManagement();
	this->student_page1->Visible = false;
	this->student_page->Visible = false;
	this->student_page2->Visible = false;
	this->lecturer_page->Visible = true;
	this->lecturer_page1->Visible = false;
	this->lecturer_page2->Visible = false;
	this->lecturer_page3->Visible = true;

}
private: System::Void button11_Click(System::Object^ sender, System::EventArgs^ e) {
	//project
	ProjectManagement();
	this->student_page->Visible = false;
	this->student_page1->Visible = false;
	this->student_page2->Visible = false;
	this->lecturer_page->Visible = true;
	this->lecturer_page1->Visible = false;
	this->lecturer_page2->Visible = true;
	this->lecturer_page3->Visible = false;

}
private: System::Void button13_Click(System::Object^ sender, System::EventArgs^ e) {
	//markings
	Markings();
	this->student_page->Visible = false;
	this->student_page1->Visible = false;
	this->student_page2->Visible = false;
	this->lecturer_page->Visible = true;
	this->lecturer_page1->Visible = true;
	this->lecturer_page2->Visible = false;
	this->lecturer_page3->Visible = false;


}
private: System::Void button14_Click(System::Object^ sender, System::EventArgs^ e) {
	//textbox16
	//delete practical
		//database connectivity
	String^ Str = "Server = 127.0.0.1; Uid = root; Pwd = ; Database = ukzneng_stusystem";
	MySqlConnection^ connection = gcnew MySqlConnection(Str);
	MySqlCommand^ command = gcnew MySqlCommand("select * from practical_slot;", connection);
	MySqlDataReader^ dr;
	try {
		connection->Open();
		dr = command->ExecuteReader();
		int count = 0;
		while (dr->Read())
		{
			count++;
		}
		if (count != 1) {
			//delete from the user
			MySqlConnection^ connection1 = gcnew MySqlConnection(Str);
			MySqlCommand^ cmd1 = gcnew MySqlCommand("DELETE FROM practical_slot where practical_id='" + textBox16->Text + "'; ", connection1);

			MySqlDataReader^ dr1;
			try {
				connection1->Open();
				dr1 = cmd1->ExecuteReader();
				int count = 0;
				while (dr1->Read())
				{
					count++;
				}
				if (count != 1) {
					
					//store data to database
					MessageBox::Show("Deleted !");
					connection1->Close();
					//show dashboad
					textBox16->Clear();
					connection1->Close();
				}

				else
				{
					MessageBox::Show("Could not delete data!");
				}
			}
			catch (Exception^ ex)
			{
				MessageBox::Show(ex->Message);
			}
		}

		else
		{
			MessageBox::Show("No Record Found");


		}
	}
	catch (Exception^ ex)
	{
		MessageBox::Show(ex->Message);
	}

}
private: System::Void button16_Click(System::Object^ sender, System::EventArgs^ e) {
	this->student_page->Visible = true;
	this->student_page1->Visible = false;
	this->student_page2->Visible = false;
	this->lecturer_page->Visible = false;
	this->lecturer_page1->Visible = false;
	this->lecturer_page2->Visible = false;
	this->lecturer_page3->Visible = false;
	this->admin_page->Visible = false;

}
private: System::Void button23_Click(System::Object^ sender, System::EventArgs^ e) {
	this->student_page->Visible = false;
	this->student_page1->Visible = false;
	this->student_page2->Visible = false;
	this->lecturer_page->Visible = false;
	this->lecturer_page1->Visible = false;
	this->lecturer_page2->Visible = false;
	this->lecturer_page3->Visible = false;
	this->admin_page->Visible = false;
	this->login_page->Visible = true;

}
private: System::Void button17_Click(System::Object^ sender, System::EventArgs^ e) {
	//datagrid 5
	//add students
	Adduser();
}
private: System::Void Addlecturer()
	   {
		   if (String::IsNullOrEmpty(textBox4->Text) || String::IsNullOrEmpty(textBox5->Text) || String::IsNullOrEmpty(textBox6->Text))
		   {
			   MessageBox::Show("Please Fill Empty Fields");
		   }
		   else
		   {
			   String^ Str = "Server = 127.0.0.1; Uid = root; Pwd = ; Database = ukzneng_stusystem";
			   MySqlConnection^ connection = gcnew MySqlConnection(Str);
			   {
				   MySqlCommand^ command = gcnew MySqlCommand("select * from all_members where id = '" + this->textBox5->Text + "' ;", connection);
				   MySqlDataReader^ dr;
				   try
				   {
					   connection->Open();
					   dr = command->ExecuteReader();
					   int c = 0;
					   while (dr->Read())
					   {
						   c++;
					   }
					   if (c != 1)
					   {
						   MySqlConnection^ connection2 = gcnew MySqlConnection(Str);
						   MySqlCommand^ command2 = gcnew MySqlCommand("select * FROM lecturer_table where staff_id = '" + this->textBox5->Text + "'; ", connection2);
						   MySqlDataReader^ dr;
						   try {
							   connection2->Open();
							   dr = command2->ExecuteReader();
							   int c = 0;
							   while (dr->Read())
							   {
								   c++;
							   }
							   if (c != 1)
							   {
								   //save
								   MySqlConnection^ connection3 = gcnew MySqlConnection(Str);
								   MySqlConnection^ connection4 = gcnew MySqlConnection(Str);
								   try
								   {
									   String^ password = "stuff2021";
									   String^ group = "lecturer";
									   //student database
									   MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO lecturer_table (staff_id, lecturer_name,email_address) VALUES ('" + textBox5->Text + "','" + textBox4->Text + "','" + textBox6->Text + "')", connection3);
									   MySqlDataReader^ dr;
									   connection3->Open();
									   dr = cmd->ExecuteReader();

									   //all members database
									   MySqlCommand^ cmd1 = gcnew MySqlCommand("INSERT INTO all_members (id, password, fullname, email_address,member_group) VALUES ('" + textBox5->Text + "','" + password + "','" + textBox4->Text + "','" + textBox6->Text + "','" + group + "')", connection4);
									   MySqlDataReader^ dr1;
									   connection4->Open();
									   dr1 = cmd1->ExecuteReader();

									   MessageBox::Show("Stuff Added");
									   textBox4->Clear();//clear 
									   textBox5->Clear();//clear
									   textBox6->Clear();//clear


								   }
								   catch (Exception^ ex)
								   {
									   MessageBox::Show(ex->Message);
								   }
							   }
							   else
							   {
								   MessageBox::Show("Stuff Already Registered");

							   }

						   }
						   catch (Exception^ ex)
						   {
							   MessageBox::Show(ex->Message);
						   }
					   }
					   else
					   {
						   MessageBox::Show("Stuff  Already Registered");
					   }
				   }
				   catch (Exception^ ex)
				   {
					   MessageBox::Show(ex->Message);
				   }
			   }


		   }
	   }
private: System::Void Adduser()
			  {
				  if (String::IsNullOrEmpty(textBox1->Text) || String::IsNullOrEmpty(textBox2->Text) || String::IsNullOrEmpty(textBox3->Text))
				  {
					  MessageBox::Show("Please Fill Empty Fields");
				  }
				  else
				  {
					  String^ Str = "Server = 127.0.0.1; Uid = root; Pwd = ; Database = ukzneng_stusystem";
					  MySqlConnection^ connection = gcnew MySqlConnection(Str);
					  {
						  MySqlCommand^ command = gcnew MySqlCommand("select * from all_members where id = '" + this->textBox2->Text + "' ;", connection);
						  MySqlDataReader^ dr;
						  try
						  {
							  connection->Open();
							  dr = command->ExecuteReader();
							  int c = 0;
							  while (dr->Read())
							  {
								  c++;
							  }
							  if (c != 1)
							  {
								  MySqlConnection^ connection2 = gcnew MySqlConnection(Str);
								  MySqlCommand^ command2 = gcnew MySqlCommand("select * FROM student_table where student_id = '" + this->textBox4->Text + "'; ", connection2);
								  MySqlDataReader^ dr;
								  try {
									  connection2->Open();
									  dr = command2->ExecuteReader();
									  int c = 0;
									  while (dr->Read())
									  {
										  c++;
									  }
									  if (c != 1)
									  {
										  //save
										  MySqlConnection^ connection3 = gcnew MySqlConnection(Str);
										  MySqlConnection^ connection4 = gcnew MySqlConnection(Str);
										  try
										  {
											  String^ password = "stu2021";
											  String^ group = "student";
											  //student database
											  MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO student_table (student_id, student_name,email_address) VALUES ('" + textBox2->Text + "','" + textBox1->Text + "','" + textBox3->Text + "')", connection3);
											  MySqlDataReader^ dr;
											  connection3->Open();
											  dr = cmd->ExecuteReader();

											  //all members database
											  MySqlCommand^ cmd1 = gcnew MySqlCommand("INSERT INTO all_members (id, password, fullname, email_address,member_group) VALUES ('" + textBox2->Text + "','" + password + "','" + textBox1->Text + "','" + textBox3->Text + "','" + group + "')", connection4);
											  MySqlDataReader^ dr1;
											  connection4->Open();
											  dr1 = cmd1->ExecuteReader();

											  MessageBox::Show("Student Added");
											  textBox1->Clear();//clear 
											  textBox2->Clear();//clear
											  textBox3->Clear();//clear


										  }
										  catch (Exception^ ex)
										  {
											  MessageBox::Show(ex->Message);
										  }
									  }
									  else
									  {
										  MessageBox::Show("Student Already Registered");

									  }

								  }
								  catch (Exception^ ex)
								  {
									  MessageBox::Show(ex->Message);
								  }
							  }
							  else
							  {
								  MessageBox::Show("Student Already Registered");
							  }
						  }
						  catch (Exception^ ex)
						  {
							  MessageBox::Show(ex->Message);
						  }
					  }


				  }
			  }
private: System::Void AddProject()
{
	//textbox 7,8,8, 12
// //combobox 4
// //rich field 1
	if (String::IsNullOrEmpty(textBox7->Text) || String::IsNullOrEmpty(textBox8->Text) || String::IsNullOrEmpty(textBox9->Text) || String::IsNullOrEmpty(comboBox5->Text) || String::IsNullOrEmpty(comboBox4->Text) || String::IsNullOrEmpty(richTextBox1->Text))
	{
		MessageBox::Show("Please Fill Empty Fields");
	}
	else
	{
		String^ Str = "Server = 127.0.0.1; Uid = root; Pwd = ; Database = ukzneng_stusystem";
		MySqlConnection^ connection = gcnew MySqlConnection(Str);
		{
			MySqlCommand^ command = gcnew MySqlCommand("select * from projects_table where project_id = '" + this->textBox7->Text + "' ;", connection);
			MySqlDataReader^ dr;
			try
			{
				connection->Open();
				dr = command->ExecuteReader();
				int c = 0;
				while (dr->Read())
				{
					c++;
				}
				if (c != 1)
				{

					{
						        MySqlConnection^ connection3 = gcnew MySqlConnection(Str);
								//student database
								MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO projects_table (project_id, project_tittle,lecturer_name,problem_description,eligibility,implementation) VALUES ('" + textBox7->Text + "','" + textBox8->Text + "','" + textBox9->Text + "','" + comboBox5->Text + "','" + comboBox4->Text + "','" + richTextBox1->Text + "')", connection3);
								MySqlDataReader^ dr;
								connection3->Open();
								dr = cmd->ExecuteReader();
								ProjectManagement();
								MessageBox::Show("Project Added");
								textBox7->Clear();//clear 
								textBox8->Clear();//clear
								textBox9->Clear();//clear
								comboBox5->Items->Clear();//clear 
								comboBox4->Items->Clear();//clear
								richTextBox1->Clear();//clear
				   }
			
				}
				else
				{
					MessageBox::Show("Project Already Exist in the system");
				}
			}
			catch (Exception^ ex)
			{
				MessageBox::Show(ex->Message);
			}
		}


	}
}
private: System::Void AddPractical()
	   {
		   //textbox 7,8,8, 12
	   // //combobox 4
	   // //rich field 1
		   if (String::IsNullOrEmpty(textBox13->Text) || String::IsNullOrEmpty(textBox14->Text) || String::IsNullOrEmpty(textBox15->Text) || String::IsNullOrEmpty(textBox17->Text) || String::IsNullOrEmpty(comboBox3->Text))
		   {
			   MessageBox::Show("Please Fill Empty Fields");
		   }
		   else
		   {
			   String^ Str = "Server = 127.0.0.1; Uid = root; Pwd = ; Database = ukzneng_stusystem";
			   MySqlConnection^ connection = gcnew MySqlConnection(Str);
			   {
				   MySqlCommand^ command = gcnew MySqlCommand("select * from practical_slot where practical_id = '" + this->textBox7->Text + "' ;", connection);
				   MySqlDataReader^ dr;
				   try
				   {
					   connection->Open();
					   dr = command->ExecuteReader();
					   int c = 0;
					   while (dr->Read())
					   {
						   c++;
					   }
					   if (c != 1)
					   {

						   {
							   MySqlConnection^ connection3 = gcnew MySqlConnection(Str);
							   //student database
							   MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO practical_slot (module,practical_id,prac_name,practical_tittle,date_time) VALUES ('" + textBox13->Text + "','" + textBox14->Text + "','" + textBox15->Text + "','" + textBox17->Text + "','" + comboBox3->Text + "')", connection3);
							   MySqlDataReader^ dr;
							   connection3->Open();
							   dr = cmd->ExecuteReader();
							   PracticalManagement();
							   MessageBox::Show("Practical Added");
							   textBox7->Clear();//clear 
							   textBox8->Clear();//clear
							   textBox9->Clear();//clear
							   comboBox5->Items->Clear();//clear 
							   comboBox4->Items->Clear();//clear
							   richTextBox1->Clear();//clear
						   }

					   }
					   else
					   {
						   MessageBox::Show("Practical Already Exist in the system");
					   }
				   }
				   catch (Exception^ ex)
				   {
					   MessageBox::Show(ex->Message);
				   }
			   }


		   }
	   }
private: System::Void button20_Click(System::Object^ sender, System::EventArgs^ e) {
	//datagrid 6
//add staff members
	this->admin_page2->Visible = true;
	this->admin_page1->Visible = false;

}
private: System::Void button19_Click(System::Object^ sender, System::EventArgs^ e) {
	//admin page 2
	//add stuff
	Addlecturer();
}
private: System::Void label12_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void button22_Click(System::Object^ sender, System::EventArgs^ e) {
	//admin page1
	this->admin_page1->Visible = true;
	this->admin_page2->Visible = false;


}
private: System::Void button21_Click(System::Object^ sender, System::EventArgs^ e) {
	//add new practical
	// //13-17
	// //combo3
	//
	AddPractical();
}
private: System::Void button18_Click(System::Object^ sender, System::EventArgs^ e) {
	//textbox16
		//delete practical
			//database connectivity
	String^ Str = "Server = 127.0.0.1; Uid = root; Pwd = ; Database = ukzneng_stusystem";
	MySqlConnection^ connection = gcnew MySqlConnection(Str);
	MySqlCommand^ command = gcnew MySqlCommand("select * from projects_table;", connection);
	MySqlDataReader^ dr;
	try {
		connection->Open();
		dr = command->ExecuteReader();
		int count = 0;
		while (dr->Read())
		{
			count++;
		}
		if (count != 1) {
			//delete from the user
			MySqlConnection^ connection1 = gcnew MySqlConnection(Str);
			MySqlCommand^ cmd1 = gcnew MySqlCommand("DELETE FROM projects_table where project_id='" + textBox7->Text + "'; ", connection1);

			MySqlDataReader^ dr1;
			try {
				connection1->Open();
				dr1 = cmd1->ExecuteReader();
				int count = 0;
				while (dr1->Read())
				{
					count++;
				}
				if (count != 1) {

					//store data to database
					MessageBox::Show("Deleted !");
					connection1->Close();
					//show dashboad
					textBox7->Clear();
					connection1->Close();
				}

				else
				{
					MessageBox::Show("Could not delete data!");
				}
			}
			catch (Exception^ ex)
			{
				MessageBox::Show(ex->Message);
			}
		}

		else
		{
			MessageBox::Show("No Record Found");


		}
	}
	catch (Exception^ ex)
	{
		MessageBox::Show(ex->Message);
	}
}
private: System::Void admin_page_Paint(System::Object^ sender, System::Windows::Forms::PaintEventArgs^ e) {
	this->admin_page1->Visible = true;
	this->admin_page2->Visible = false;
}
private: System::Void login_page_Paint(System::Object^ sender, System::Windows::Forms::PaintEventArgs^ e) {
}
};
}
